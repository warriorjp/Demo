package com.springboot.blog.controller;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;


@RestController
@RequestMapping("/api/v1")
public class UserController {

    


    @GetMapping("/welcome")
    public String getCommentsByPostId(){
        return "Welcome To VI Hrutuja!";
    }

  
}
