package com.springboot.blog.service;



public interface AuthService {

	String resetpassowrd(String userNameOrEmailId,String Password);
}
