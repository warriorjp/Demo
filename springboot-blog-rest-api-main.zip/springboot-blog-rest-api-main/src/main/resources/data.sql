

CREATE TABLE IF NOT EXISTS `roles` (
   `id` bigint NOT NULL,
   `name` varchar(60) DEFAULT NULL,
   PRIMARY KEY (`id`)
);

INSERT INTO roles (id, name) VALUES (1, 'ROLE_USER');
INSERT INTO roles (id, name) VALUES (2, 'ROLE_ADMIN');


